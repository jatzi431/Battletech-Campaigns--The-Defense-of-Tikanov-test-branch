extends Node2D

#Script is for controlling map, unit locations, fog of war, unit movement?

@onready var unit_spawn_pos = $PlayerUnitSpawnMarker
@onready var player_unit_container = $PlayerUnitContainer
@onready var map = $Map
#Loading scenes is better for units, bullets, things that are dynamic
var test_unit = load("res://Scenes/Test Unit.tscn")
var currently_selected_unit: int = -1
var selected_units:Array = []

func _ready() -> void:
	spawn_unit(Vector2i(5, 3), "1st Guards") #Grid is 24x13 for now
	spawn_unit(Vector2i(11, 7), "2nd Guards")
	
	#Selecting Units stuff
	#get_viewport().physics_object_picking = true
	#get_viewport().physics_object_picking_first_only = true
	#get_viewport().physics_object_picking_sort = true
#
	#$Background/CollisionShape2D.shape.size = get_viewport().size
	#$Background.position = get_viewport().size / 2
	#$Background.input_event.connect(_on_background_input_event)
	


func spawn_unit(hex_coords: Vector2i, name: String) -> void:
	var new_unit = test_unit.instantiate()
	var world_position = map.map_to_local(hex_coords)
	new_unit.position = world_position
	player_unit_container.add_child(new_unit)
	new_unit.unit_id = name
	print(world_position)
	#new_unit.unit_clicked.connect(_on_unit_clicked)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_mask == MOUSE_BUTTON_LEFT:
			if event.pressed == true:
				var result= check_if_something_at_position(event.position)
				if result == null:
					print ("Nothing here !!!")
					#First Deselect current selected units
					for unit in selected_units:
						unit.collider.toggle_selection(false)
					selected_units = []
				else:
					var selected:bool = result[0].collider.selected
					result[0].collider.toggle_selection(not selected)
					print("Unit was selected")

#func _on_unit_clicked(unit_id: int) -> void:
	#print("Unit %s was clicked" % [unit_id])
	#if currently_selected_unit >= 0:
		#player_unit_container[currently_selected_unit].set_selected(false)
	#currently_selected_unit = unit_id
	#player_unit_container[currently_selected_unit].set_selected(true)
#
#func _on_background_input_event(_viewport: Node, event: InputEvent, _shape_idx: int) -> void:
	#if event is InputEventMouseButton and event.pressed:
		#if currently_selected_unit >= 0:
			#player_unit_container[currently_selected_unit].set_selected(false)
			#print("Unit %s was deselected" % [currently_selected_unit])
			#currently_selected_unit = -1

func check_if_something_at_position(target:Vector2):
	var space_state = get_world_2d().direct_space_state
	var query = PhysicsPointQueryParameters2D.new()
	query.collide_with_areas = true
	query.position = target
	var result:Array = space_state.intersect_point(query, 32)
	#Result is an array of dictionaries, right?
	if result:
		return result
