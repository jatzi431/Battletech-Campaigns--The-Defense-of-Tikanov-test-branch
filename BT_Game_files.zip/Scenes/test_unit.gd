extends CharacterBody2D

signal unit_clicked(id: int)

var head_armor = 10
var center_torso_armor = 30
var left_torso_armor = 20
var right_torso_armor = 20
var left_arm_armor = 20
var right_arm_armor = 20
var left_leg_armor = 10
var right_leg_armor = 10

@export var unit_id: String = ""

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_mask == MOUSE_BUTTON_LEFT:
			unit_clicked.emit(unit_id)
			get_viewport()

func set_selected(switch_on: bool) -> void:
	$Line2D.visible = switch_on
